package dev.mediacontroller.app

import android.content.ComponentName
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService

// Android only gives access to other apps' media sessions to a notification listener.
// The user enables it once in Settings; after that this service keeps the list up to date.
class MediaListenerService : NotificationListenerService() {

    private var manager: MediaSessionManager? = null
    private val attached = mutableMapOf<MediaController, MediaController.Callback>()
    private val handler = Handler(Looper.getMainLooper())

    private val sessionsChanged = MediaSessionManager.OnActiveSessionsChangedListener { list ->
        attach(list ?: emptyList())
    }

    override fun onListenerConnected() {
        val mgr = getSystemService(MediaSessionManager::class.java) ?: return
        manager = mgr
        val component = ComponentName(this, MediaListenerService::class.java)
        mgr.addOnActiveSessionsChangedListener(sessionsChanged, component)
        attach(mgr.getActiveSessions(component))
    }

    override fun onListenerDisconnected() {
        manager?.removeOnActiveSessionsChangedListener(sessionsChanged)
        detachAll()
        MediaRepository.clear()
    }

    private fun attach(list: List<MediaController>) {
        val keep = list.toSet()

        // Drop callbacks for sessions that are gone.
        for (c in attached.keys.toList()) {
            if (c !in keep) {
                attached.remove(c)?.let { c.unregisterCallback(it) }
            }
        }

        // Watch new sessions for metadata and play/pause changes.
        for (c in list) {
            if (attached.containsKey(c)) continue
            val cb = object : MediaController.Callback() {
                override fun onMetadataChanged(metadata: MediaMetadata?) {
                    MediaRepository.publish()
                }

                override fun onPlaybackStateChanged(state: PlaybackState?) {
                    MediaRepository.publish()
                }

                override fun onSessionDestroyed() {
                    MediaRepository.publish()
                }
            }
            c.registerCallback(cb, handler)
            attached[c] = cb
        }

        MediaRepository.setControllers(list)
    }

    private fun detachAll() {
        attached.forEach { (c, cb) -> c.unregisterCallback(cb) }
        attached.clear()
    }
}
