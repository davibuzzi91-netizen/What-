package dev.mediacontroller.app

import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.PlaybackState

// One active media session on the phone (Spotify, YouTube Music, etc.).
data class NowPlaying(
    val controller: MediaController,
    val app: String,
    val title: String,
    val artist: String,
    val playing: Boolean
)

// Shared state between the notification listener service and the screen.
// Everything runs on the main thread.
object MediaRepository {
    private const val OWN_PACKAGE = "dev.mediacontroller.app"

    private val controllers = mutableListOf<MediaController>()
    private val listeners = mutableListOf<() -> Unit>()

    var items: List<NowPlaying> = emptyList()
        private set

    fun setControllers(list: List<MediaController>) {
        controllers.clear()
        controllers.addAll(list)
        publish()
    }

    fun clear() {
        controllers.clear()
        publish()
    }

    fun addListener(listener: () -> Unit) {
        listeners.add(listener)
    }

    fun removeListener(listener: () -> Unit) {
        listeners.remove(listener)
    }

    fun publish() {
        items = controllers.filter { it.packageName != OWN_PACKAGE }.map { c ->
            val m = c.metadata
            val state = c.playbackState?.state
            NowPlaying(
                controller = c,
                app = c.packageName,
                title = m?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "(sem título)",
                artist = m?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: "",
                playing = state == PlaybackState.STATE_PLAYING
            )
        }
        listeners.toList().forEach { it() }
    }
}
