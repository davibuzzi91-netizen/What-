package dev.mediacontroller.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.Icon
import android.util.Base64
import android.media.MediaMetadata
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper

// Foreground service with a media notification (title, artist, previous / play-pause / next).
// It keeps the app alive so the page's audio keeps playing while the app is in the recents list.
class PlaybackService : Service() {

    private var session: MediaSession? = null
    private var title = "Reprodutor Ondulado"
    private var artist = ""
    private var playing = false
    private var cover: Bitmap? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    // Watches the other apps' media. When one starts playing, this player pauses.
    private var lastPlayingApps: Set<String> = emptySet()
    private val externalWatcher: () -> Unit = {
        val playingNow = MediaRepository.items.filter { it.playing }.map { it.app }.toSet()
        if (playingNow.any { it !in lastPlayingApps }) send("pause")
        lastPlayingApps = playingNow
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        createChannel()
        MediaRepository.addListener(externalWatcher)

        val s = MediaSession(this, "ReprodutorOndulado")
        s.setCallback(object : MediaSession.Callback() {
            override fun onPlay() { send("toggle") }
            override fun onPause() { send("toggle") }
            override fun onSkipToNext() { send("next") }
            override fun onSkipToPrevious() { send("prev") }
        })
        s.isActive = true
        session = s
    }

    override fun onDestroy() {
        MediaRepository.removeListener(externalWatcher)
        if (instance === this) instance = null
        session?.release()
        session = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_TOGGLE -> send("toggle")
            ACTION_NEXT -> send("next")
            ACTION_PREV -> send("prev")
        }
        refresh()
        return START_STICKY
    }

    // Called by the page (through MediaBridge) when the track or its play state changes.
    fun updateNowPlaying(newTitle: String, newArtist: String, isPlaying: Boolean) {
        title = newTitle
        artist = newArtist
        playing = isPlaying
        refresh()
    }

    // Receives the current track's image as a data URL ("" removes it).
    fun updateCover(dataUrl: String) {
        val comma = dataUrl.indexOf(',')
        cover = if (dataUrl.isEmpty() || comma < 0) {
            null
        } else {
            try {
                val bytes = Base64.decode(dataUrl.substring(comma + 1), Base64.DEFAULT)
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            } catch (e: Exception) {
                null
            }
        }
        refresh()
    }

    private fun send(action: String) {
        mainHandler.post { controlSink?.invoke(action) }
    }

    private fun refresh() {
        val s = session ?: return
        s.setMetadata(
            MediaMetadata.Builder()
                .putString(MediaMetadata.METADATA_KEY_TITLE, title)
                .putString(MediaMetadata.METADATA_KEY_ARTIST, artist)
                .apply { cover?.let { putBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART, it) } }
                .build()
        )
        s.setPlaybackState(
            PlaybackState.Builder()
                .setActions(
                    PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_PLAY_PAUSE or
                        PlaybackState.ACTION_SKIP_TO_NEXT or PlaybackState.ACTION_SKIP_TO_PREVIOUS
                )
                .setState(
                    if (playing) PlaybackState.STATE_PLAYING else PlaybackState.STATE_PAUSED,
                    PlaybackState.PLAYBACK_POSITION_UNKNOWN,
                    1f
                )
                .build()
        )

        val notification = buildNotification(s)
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun buildNotification(s: MediaSession): Notification {
        val builder = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(
                when {
                    artist.isNotEmpty() -> artist
                    playing -> "Tocando"
                    else -> "Pausado"
                }
            )
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setOngoing(playing)
            .setStyle(
                Notification.MediaStyle()
                    .setMediaSession(s.sessionToken)
                    .setShowActionsInCompactView(0, 1, 2)
            )
        cover?.let { builder.setLargeIcon(it) }
        builder.addAction(action(android.R.drawable.ic_media_previous, "Anterior", ACTION_PREV, 1))
        builder.addAction(
            action(
                if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play,
                if (playing) "Pausar" else "Tocar",
                ACTION_TOGGLE,
                2
            )
        )
        builder.addAction(action(android.R.drawable.ic_media_next, "Próxima", ACTION_NEXT, 3))
        return builder.build()
    }

    private fun action(icon: Int, label: String, act: String, code: Int): Notification.Action {
        val intent = Intent(this, PlaybackService::class.java).setAction(act)
        val pi = PendingIntent.getService(
            this, code, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Action.Builder(Icon.createWithResource(this, icon), label, pi).build()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "Reprodução", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    companion object {
        const val CHANNEL_ID = "playback"
        const val NOTIFICATION_ID = 1
        const val ACTION_TOGGLE = "dev.mediacontroller.TOGGLE"
        const val ACTION_NEXT = "dev.mediacontroller.NEXT"
        const val ACTION_PREV = "dev.mediacontroller.PREV"

        var instance: PlaybackService? = null

        // MainActivity sets this so notification buttons reach the page's player.
        var controlSink: ((String) -> Unit)? = null
    }
}
