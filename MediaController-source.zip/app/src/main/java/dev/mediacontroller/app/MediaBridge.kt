package dev.mediacontroller.app

import android.content.Intent
import android.provider.Settings
import android.webkit.JavascriptInterface

// Methods the page calls through window.Android. JavaScript bridge calls arrive on a
// background thread, so every change is moved to the main thread.
class MediaBridge(private val activity: MainActivity) {

    @JavascriptInterface
    fun setNowPlaying(title: String, artist: String, playing: Boolean) {
        activity.runOnUiThread {
            PlaybackService.instance?.updateNowPlaying(title, artist, playing)
        }
    }

    @JavascriptInterface
    fun controlExternal(index: Int, action: String) {
        activity.runOnUiThread {
            val item = MediaRepository.items.getOrNull(index) ?: return@runOnUiThread
            val controls = item.controller.transportControls ?: return@runOnUiThread
            when (action) {
                "toggle" -> if (item.playing) controls.pause() else controls.play()
                "next" -> controls.skipToNext()
                "prev" -> controls.skipToPrevious()
            }
        }
    }

    @JavascriptInterface
    fun openListenerSettings() {
        activity.runOnUiThread {
            activity.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
    }
}
