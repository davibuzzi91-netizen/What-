package dev.mediacontroller.app

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var listBox: LinearLayout

    private val refresher: () -> Unit = { render() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#121117"))
            setPadding(48, 96, 48, 48)
        }

        val title = TextView(this).apply {
            text = "Media Controller"
            textSize = 24f
            setTextColor(Color.WHITE)
        }

        status = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.parseColor("#9A95A8"))
            setPadding(0, 12, 0, 24)
        }

        val access = Button(this).apply {
            text = "Dar acesso às notificações"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
        }

        listBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 32, 0, 0)
        }

        root.addView(title)
        root.addView(status)
        root.addView(access)
        root.addView(listBox)
        setContentView(root)
    }

    override fun onStart() {
        super.onStart()
        MediaRepository.addListener(refresher)
        render()
    }

    override fun onStop() {
        MediaRepository.removeListener(refresher)
        super.onStop()
    }

    private fun hasAccess(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        return enabled.contains(ComponentName(this, MediaListenerService::class.java).flattenToString())
    }

    private fun render() {
        if (!hasAccess()) {
            status.text = "Ative o acesso às notificações para ver o que está tocando."
            listBox.removeAllViews()
            return
        }

        val items = MediaRepository.items
        status.text = if (items.isEmpty()) {
            "Nenhuma mídia ativa no momento."
        } else {
            "${items.size} mídia(s) ativa(s)."
        }

        listBox.removeAllViews()
        for (item in items) {
            listBox.addView(card(item))
        }
    }

    private fun card(item: NowPlaying): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#1C1A24"))
            setPadding(32, 28, 32, 28)
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = 24 }
        }

        box.addView(TextView(this).apply {
            text = item.app + if (item.playing) " · tocando" else " · pausado"
            textSize = 12f
            setTextColor(Color.parseColor("#B9AEFF"))
        })
        box.addView(TextView(this).apply {
            text = item.title
            textSize = 18f
            setTextColor(Color.WHITE)
            setPadding(0, 8, 0, 0)
        })
        box.addView(TextView(this).apply {
            text = item.artist
            textSize = 14f
            setTextColor(Color.parseColor("#9A95A8"))
        })

        val c = item.controller
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, 20, 0, 0)
        }
        row.addView(Button(this).apply {
            text = "⏮"
            setOnClickListener { c.transportControls?.skipToPrevious() }
        })
        row.addView(Button(this).apply {
            text = if (item.playing) "⏸" else "▶"
            setOnClickListener {
                if (item.playing) c.transportControls?.pause() else c.transportControls?.play()
            }
        })
        row.addView(Button(this).apply {
            text = "⏭"
            setOnClickListener { c.transportControls?.skipToNext() }
        })
        box.addView(row)

        return box
    }
}
