package dev.mediacontroller.app

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject

// Shows the player page (assets/index.html) full screen. The page runs its own audio,
// library, MP3 import and tests. A foreground service keeps playback alive in the background.
class MainActivity : Activity() {

    private lateinit var webView: WebView
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private val externalRefresh: () -> Unit = { pushExternal() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this)
        setContentView(webView)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            mediaPlaybackRequiresUserGesture = false
        }

        webView.addJavascriptInterface(MediaBridge(this), "Android")

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                pushExternal()
            }
        }

        // The MP3 picker: the page's <input type="file"> opens the phone's file chooser.
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView?,
                callback: ValueCallback<Array<Uri>>?,
                params: FileChooserParams?
            ): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = callback
                val intent = params?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply { type = "*/*" }
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                return try {
                    startActivityForResult(intent, FILE_REQUEST)
                    true
                } catch (e: Exception) {
                    filePathCallback = null
                    false
                }
            }
        }

        // Notification buttons call the page's player through this.
        PlaybackService.controlSink = { action ->
            webView.evaluateJavascript("if (window.nativeControl) nativeControl('$action')", null)
        }

        webView.loadUrl("file:///android_asset/index.html")

        startPlaybackService()
        askNotificationPermission()
    }

    override fun onStart() {
        super.onStart()
        MediaRepository.addListener(externalRefresh)
        pushExternal()
    }

    override fun onStop() {
        MediaRepository.removeListener(externalRefresh)
        super.onStop()
    }

    override fun onDestroy() {
        PlaybackService.controlSink = null
        super.onDestroy()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == FILE_REQUEST) {
            val result = if (resultCode == RESULT_OK && data != null) {
                WebChromeClient.FileChooserParams.parseResult(resultCode, data)
            } else {
                null
            }
            filePathCallback?.onReceiveValue(result)
            filePathCallback = null
        }
    }

    // Sends the other apps' media sessions to the page's "Em outros apps" section.
    private fun pushExternal() {
        val granted = hasListenerAccess()
        val list = JSONArray()
        if (granted) {
            MediaRepository.items.forEachIndexed { i, item ->
                list.put(
                    JSONObject()
                        .put("index", i)
                        .put("app", item.app)
                        .put("title", item.title)
                        .put("artist", item.artist)
                        .put("playing", item.playing)
                )
            }
        }
        webView.evaluateJavascript("if (window.onExternal) onExternal($list, $granted)", null)
    }

    private fun hasListenerAccess(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        return enabled.contains(ComponentName(this, MediaListenerService::class.java).flattenToString())
    }

    private fun startPlaybackService() {
        val intent = Intent(this, PlaybackService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }

    // Android 13+ asks for permission to show notifications; the playback notification needs it.
    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), NOTIFICATION_REQUEST)
        }
    }

    companion object {
        private const val FILE_REQUEST = 42
        private const val NOTIFICATION_REQUEST = 43
    }
}
